select * from ACCOUNT_MASTER;

select * from CUSTOMER ;

drop sequence custid_seq;

SELECT * FROM ACCOUNT_MASTER;

create table RequestTable
(
customer_ID number(10) primary key,
AccountType varchar2(15),
AccountId number(10)
);



select * from USER_TABLE;

create table Service_Tracker(
Service_ID NUMBER(15) primary key, 
Service_Description VARCHAR2(100),
Account_ID NUMBER, 

Service_Raised_Date DATE ,
Service_status VARCHAR2(20),
foreign key(Account_ID) references Account_Master(Account_ID) 
);


create table Payee_Table
(
Payee_Account_Id NUMBER primary key, 
Account_Id NUMBER,
Nick_name VARCHAR2(40),
foreign key(Account_ID) references Account_Master(Account_ID)
);

select * from service_tracker;


delete from service_tracker;

create sequence custid_seq start with 1500243 increment by 1 nocache;
select custid_seq.nextVal from dual;

select accid_seq.nextVal from dual;

select accid_seq from dual

drop sequence accid_seq;

create sequence accid_seq start with 1000000 increment by 1 nocache;
seq_service_num

create sequence seq_service_num start with 10000 increment by 1 nocache;
select * from REQUESTTABLE;